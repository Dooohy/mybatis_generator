package cn.enn.ygego.sunny.order.dao;

import cn.enn.ygego.sunny.order.dao.example.TakeDetailExample;
import cn.enn.ygego.sunny.order.model.TakeDetail;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface TakeDetailMapper {
    long countByExample(TakeDetailExample example);

    int deleteByExample(TakeDetailExample example);

    int deleteByPrimaryKey(Long takeDetailId);

    int insert(TakeDetail record);

    int insertSelective(TakeDetail record);

    List<TakeDetail> selectByExample(TakeDetailExample example);

    TakeDetail selectByPrimaryKey(Long takeDetailId);

    int updateByExampleSelective(@Param("record") TakeDetail record, @Param("example") TakeDetailExample example);

    int updateByExample(@Param("record") TakeDetail record, @Param("example") TakeDetailExample example);

    int updateByPrimaryKeySelective(TakeDetail record);

    int updateByPrimaryKey(TakeDetail record);

    TakeDetail selectOneByExample(TakeDetailExample example);
}