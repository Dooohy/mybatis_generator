package cn.enn.ygego.sunny.order.model;

import java.io.Serializable;
import java.math.BigDecimal;

public class TakeDetail implements Serializable {
    /**
     * 取货单明细ID
     */
    private Long takeDetailId;

    /**
     * 单品ID
     */
    private Long itemId;

    /**
     * 商品ID
     */
    private Long goodsId;

    /**
     * 物料ID
     */
    private Long materialId;

    /**
     * 物料名称
     */
    private String materialName;

    /**
     * 物料编码
     */
    private String materialCode;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 商品数量
     */
    private BigDecimal goodsCnt;

    /**
     * 实际取货数量
     */
    private BigDecimal actualTakeCnt;

    /**
     * 源单据类型
     */
    private Byte sourceBillType;

    /**
     * 源单据ID
     */
    private Long sourceBillId;

    /**
     * 源单据明细ID
     */
    private Long sourceBillDetailId;

    /**
     * 取货单ID
     */
    private Long takeId;

    private static final long serialVersionUID = 1L;

    public Long getTakeDetailId() {
        return takeDetailId;
    }

    public void setTakeDetailId(Long takeDetailId) {
        this.takeDetailId = takeDetailId;
    }

    public Long getItemId() {
        return itemId;
    }

    public void setItemId(Long itemId) {
        this.itemId = itemId;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public Long getMaterialId() {
        return materialId;
    }

    public void setMaterialId(Long materialId) {
        this.materialId = materialId;
    }

    public String getMaterialName() {
        return materialName;
    }

    public void setMaterialName(String materialName) {
        this.materialName = materialName == null ? null : materialName.trim();
    }

    public String getMaterialCode() {
        return materialCode;
    }

    public void setMaterialCode(String materialCode) {
        this.materialCode = materialCode == null ? null : materialCode.trim();
    }

    public String getGoodsName() {
        return goodsName;
    }

    public void setGoodsName(String goodsName) {
        this.goodsName = goodsName == null ? null : goodsName.trim();
    }

    public BigDecimal getGoodsCnt() {
        return goodsCnt;
    }

    public void setGoodsCnt(BigDecimal goodsCnt) {
        this.goodsCnt = goodsCnt;
    }

    public BigDecimal getActualTakeCnt() {
        return actualTakeCnt;
    }

    public void setActualTakeCnt(BigDecimal actualTakeCnt) {
        this.actualTakeCnt = actualTakeCnt;
    }

    public Byte getSourceBillType() {
        return sourceBillType;
    }

    public void setSourceBillType(Byte sourceBillType) {
        this.sourceBillType = sourceBillType;
    }

    public Long getSourceBillId() {
        return sourceBillId;
    }

    public void setSourceBillId(Long sourceBillId) {
        this.sourceBillId = sourceBillId;
    }

    public Long getSourceBillDetailId() {
        return sourceBillDetailId;
    }

    public void setSourceBillDetailId(Long sourceBillDetailId) {
        this.sourceBillDetailId = sourceBillDetailId;
    }

    public Long getTakeId() {
        return takeId;
    }

    public void setTakeId(Long takeId) {
        this.takeId = takeId;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", takeDetailId=").append(takeDetailId);
        sb.append(", itemId=").append(itemId);
        sb.append(", goodsId=").append(goodsId);
        sb.append(", materialId=").append(materialId);
        sb.append(", materialName=").append(materialName);
        sb.append(", materialCode=").append(materialCode);
        sb.append(", goodsName=").append(goodsName);
        sb.append(", goodsCnt=").append(goodsCnt);
        sb.append(", actualTakeCnt=").append(actualTakeCnt);
        sb.append(", sourceBillType=").append(sourceBillType);
        sb.append(", sourceBillId=").append(sourceBillId);
        sb.append(", sourceBillDetailId=").append(sourceBillDetailId);
        sb.append(", takeId=").append(takeId);
        sb.append(", serialVersionUID=").append(serialVersionUID);
        sb.append("]");
        return sb.toString();
    }
}