package cn.enn.ygego.sunny.order.dao.example;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class TakeDetailExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public TakeDetailExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andTakeDetailIdIsNull() {
            addCriterion("TAKE_DETAIL_ID is null");
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdIsNotNull() {
            addCriterion("TAKE_DETAIL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID =", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID <>", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID >", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID >=", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdLessThan(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID <", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_DETAIL_ID <=", value, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("TAKE_DETAIL_ID in", values, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("TAKE_DETAIL_ID not in", values, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("TAKE_DETAIL_ID between", value1, value2, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeDetailIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("TAKE_DETAIL_ID not between", value1, value2, "takeDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdIsNull() {
            addCriterion("ITEM_ID is null");
            return (Criteria) this;
        }

        public Criteria andItemIdIsNotNull() {
            addCriterion("ITEM_ID is not null");
            return (Criteria) this;
        }

        public Criteria andItemIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID =", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID <>", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID >", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID >=", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdLessThan(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID <", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("ITEM_ID <=", value, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("ITEM_ID in", values, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("ITEM_ID not in", values, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("ITEM_ID between", value1, value2, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andItemIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("ITEM_ID not between", value1, value2, "itemId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdIsNull() {
            addCriterion("GOODS_ID is null");
            return (Criteria) this;
        }

        public Criteria andGoodsIdIsNotNull() {
            addCriterion("GOODS_ID is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID =", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID <>", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID >", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID >=", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdLessThan(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID <", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("GOODS_ID <=", value, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_ID in", values, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_ID not in", values, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("GOODS_ID between", value1, value2, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("GOODS_ID not between", value1, value2, "goodsId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdIsNull() {
            addCriterion("MATERIAL_ID is null");
            return (Criteria) this;
        }

        public Criteria andMaterialIdIsNotNull() {
            addCriterion("MATERIAL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andMaterialIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID =", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID <>", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID >", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID >=", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdLessThan(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID <", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("MATERIAL_ID <=", value, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_ID in", values, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_ID not in", values, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("MATERIAL_ID between", value1, value2, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("MATERIAL_ID not between", value1, value2, "materialId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameIsNull() {
            addCriterion("MATERIAL_NAME is null");
            return (Criteria) this;
        }

        public Criteria andMaterialNameIsNotNull() {
            addCriterion("MATERIAL_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andMaterialNameEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME =", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameNotEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME <>", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameGreaterThan(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME >", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameGreaterThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME >=", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameLessThan(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME <", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameLessThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME <=", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameLike(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME like", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameNotLike(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_NAME not like", value, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_NAME in", values, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameNotIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_NAME not in", values, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("MATERIAL_NAME between", value1, value2, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameNotBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("MATERIAL_NAME not between", value1, value2, "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeIsNull() {
            addCriterion("MATERIAL_CODE is null");
            return (Criteria) this;
        }

        public Criteria andMaterialCodeIsNotNull() {
            addCriterion("MATERIAL_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andMaterialCodeEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE =", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeNotEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE <>", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeGreaterThan(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE >", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeGreaterThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE >=", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeLessThan(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE <", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeLessThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE <=", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeLike(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE like", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeNotLike(String value) {
            if (value != null && value != "") {
                addCriterion("MATERIAL_CODE not like", value, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_CODE in", values, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeNotIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("MATERIAL_CODE not in", values, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("MATERIAL_CODE between", value1, value2, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeNotBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("MATERIAL_CODE not between", value1, value2, "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameIsNull() {
            addCriterion("GOODS_NAME is null");
            return (Criteria) this;
        }

        public Criteria andGoodsNameIsNotNull() {
            addCriterion("GOODS_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsNameEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME =", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME <>", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameGreaterThan(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME >", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameGreaterThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME >=", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameLessThan(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME <", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameLessThanOrEqualTo(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME <=", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameLike(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME like", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotLike(String value) {
            if (value != null && value != "") {
                addCriterion("GOODS_NAME not like", value, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_NAME in", values, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotIn(List<String> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_NAME not in", values, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("GOODS_NAME between", value1, value2, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameNotBetween(String value1, String value2) {
            if (value1 != null && value2 != null && value1 != "" && value2 != "") {
                addCriterion("GOODS_NAME not between", value1, value2, "goodsName");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntIsNull() {
            addCriterion("GOODS_CNT is null");
            return (Criteria) this;
        }

        public Criteria andGoodsCntIsNotNull() {
            addCriterion("GOODS_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andGoodsCntEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT =", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntNotEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT <>", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntGreaterThan(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT >", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntGreaterThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT >=", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntLessThan(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT <", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntLessThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("GOODS_CNT <=", value, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_CNT in", values, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntNotIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("GOODS_CNT not in", values, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("GOODS_CNT between", value1, value2, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsCntNotBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("GOODS_CNT not between", value1, value2, "goodsCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntIsNull() {
            addCriterion("ACTUAL_TAKE_CNT is null");
            return (Criteria) this;
        }

        public Criteria andActualTakeCntIsNotNull() {
            addCriterion("ACTUAL_TAKE_CNT is not null");
            return (Criteria) this;
        }

        public Criteria andActualTakeCntEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT =", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntNotEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT <>", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntGreaterThan(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT >", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntGreaterThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT >=", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntLessThan(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT <", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntLessThanOrEqualTo(BigDecimal value) {
            if (value != null) {
                addCriterion("ACTUAL_TAKE_CNT <=", value, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("ACTUAL_TAKE_CNT in", values, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntNotIn(List<BigDecimal> values) {
            if (values != null && values.size() != 0) {
                addCriterion("ACTUAL_TAKE_CNT not in", values, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("ACTUAL_TAKE_CNT between", value1, value2, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andActualTakeCntNotBetween(BigDecimal value1, BigDecimal value2) {
            if (value1 != null && value2 != null) {
                addCriterion("ACTUAL_TAKE_CNT not between", value1, value2, "actualTakeCnt");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeIsNull() {
            addCriterion("SOURCE_BILL_TYPE is null");
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeIsNotNull() {
            addCriterion("SOURCE_BILL_TYPE is not null");
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeEqualTo(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE =", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeNotEqualTo(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE <>", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeGreaterThan(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE >", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeGreaterThanOrEqualTo(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE >=", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeLessThan(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE <", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeLessThanOrEqualTo(Byte value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_TYPE <=", value, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeIn(List<Byte> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_TYPE in", values, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeNotIn(List<Byte> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_TYPE not in", values, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeBetween(Byte value1, Byte value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_TYPE between", value1, value2, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillTypeNotBetween(Byte value1, Byte value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_TYPE not between", value1, value2, "sourceBillType");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdIsNull() {
            addCriterion("SOURCE_BILL_ID is null");
            return (Criteria) this;
        }

        public Criteria andSourceBillIdIsNotNull() {
            addCriterion("SOURCE_BILL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSourceBillIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID =", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID <>", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID >", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID >=", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdLessThan(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID <", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_ID <=", value, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_ID in", values, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_ID not in", values, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_ID between", value1, value2, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_ID not between", value1, value2, "sourceBillId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdIsNull() {
            addCriterion("SOURCE_BILL_DETAIL_ID is null");
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdIsNotNull() {
            addCriterion("SOURCE_BILL_DETAIL_ID is not null");
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID =", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID <>", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID >", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID >=", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdLessThan(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID <", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID <=", value, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_DETAIL_ID in", values, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("SOURCE_BILL_DETAIL_ID not in", values, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID between", value1, value2, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andSourceBillDetailIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("SOURCE_BILL_DETAIL_ID not between", value1, value2, "sourceBillDetailId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdIsNull() {
            addCriterion("TAKE_ID is null");
            return (Criteria) this;
        }

        public Criteria andTakeIdIsNotNull() {
            addCriterion("TAKE_ID is not null");
            return (Criteria) this;
        }

        public Criteria andTakeIdEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID =", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdNotEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID <>", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdGreaterThan(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID >", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdGreaterThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID >=", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdLessThan(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID <", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdLessThanOrEqualTo(Long value) {
            if (value != null) {
                addCriterion("TAKE_ID <=", value, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("TAKE_ID in", values, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdNotIn(List<Long> values) {
            if (values != null && values.size() != 0) {
                addCriterion("TAKE_ID not in", values, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("TAKE_ID between", value1, value2, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andTakeIdNotBetween(Long value1, Long value2) {
            if (value1 != null && value2 != null) {
                addCriterion("TAKE_ID not between", value1, value2, "takeId");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialNameLikeInsensitive(String value) {
            if (value != null && value != "") {
                addCriterion("upper(MATERIAL_NAME) like", value.toUpperCase(), "materialName");
            }
            return (Criteria) this;
        }

        public Criteria andMaterialCodeLikeInsensitive(String value) {
            if (value != null && value != "") {
                addCriterion("upper(MATERIAL_CODE) like", value.toUpperCase(), "materialCode");
            }
            return (Criteria) this;
        }

        public Criteria andGoodsNameLikeInsensitive(String value) {
            if (value != null && value != "") {
                addCriterion("upper(GOODS_NAME) like", value.toUpperCase(), "goodsName");
            }
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}