import com.alibaba.druid.support.json.JSONUtils;
import com.alibaba.fastjson.JSON;
import com.github.jsonzou.jmockdata.JMockData;
import org.junit.Test;

public class BaseTest {
    @Test
    public void name() throws Exception {
    }
}
